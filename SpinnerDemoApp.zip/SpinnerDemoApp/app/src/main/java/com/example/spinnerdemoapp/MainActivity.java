package com.example.spinnerdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Spinner spnCities , spnStates;
    Button btnOK;
    ArrayAdapter<String> adapter;
    List<String> lstStates;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spnCities = findViewById(R.id.spnCities);
        spnStates = findViewById(R.id.spnStates);
        btnOK = findViewById(R.id.btnOK);

        lstStates = new ArrayList<>();
        lstStates.add("Select State");
        lstStates.add("M.P.");
        lstStates.add("Maharashtra");
        lstStates.add("Kerala");
        lstStates.add("Himachal Pradesh");
        lstStates.add("Uttarakhand");

        adapter = new ArrayAdapter<>(MainActivity.this,
        android.R.layout.simple_spinner_dropdown_item,lstStates);

        adapter.setDropDownViewResource(
                android.R.layout.select_dialog_singlechoice);

        spnStates.setAdapter(adapter);

        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String str = spnCities.getSelectedItem().toString();
                Toast.makeText(MainActivity.this,
"Selected city is : "+str, Toast.LENGTH_SHORT).show();
            }
        });

        spnStates.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(
            AdapterView<?> adapterView, View view, int i, long l) {

                TextView tv = (TextView) view;

                String str = tv.getText().toString();

                if (!str.equals("Select State")) {
                    Toast.makeText(MainActivity.this,
        "Selected state is " +str, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(
                    AdapterView<?> adapterView) {

            }
        });
    }
}




