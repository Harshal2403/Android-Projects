package com.example.menudemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView txtView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtView = findViewById(R.id.txtView);

        registerForContextMenu(txtView);

        txtView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PopupMenu pop = new PopupMenu(
                        MainActivity.this,txtView);
                MenuInflater inflater = pop.getMenuInflater();
                inflater.inflate(R.menu.pop,pop.getMenu());

                pop.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem)
                    {
                        Toast.makeText(MainActivity.this,
"Popup menu clicked", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                });

                pop.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.mnuSearch :
                Toast.makeText(this,
"You clicked search menu", Toast.LENGTH_SHORT).show();
                break;

            case R.id.mnuExit :
                finish();
                break;
        }

        return true;
    }


    @Override
    public void onCreateContextMenu(ContextMenu menu,
    View v, ContextMenu.ContextMenuInfo menuInfo) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context,menu);
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.mnuContext :
                Toast.makeText(this,
"Context Menu clicked", Toast.LENGTH_SHORT).show();
                break;
        }

        return true;
    }
}






