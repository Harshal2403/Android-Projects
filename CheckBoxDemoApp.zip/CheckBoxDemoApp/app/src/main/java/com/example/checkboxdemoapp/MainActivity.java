package com.example.checkboxdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    CheckBox chkJava , chkJS , chkC , chkCpp;
    Button btnOK;
    ToggleButton tgb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chkJS = findViewById(R.id.chkJS);
        chkCpp = findViewById(R.id.chkCpp);
        chkC = findViewById(R.id.chkC);
        chkJava = findViewById(R.id.chkJava);

        btnOK = findViewById(R.id.btnOK);

        tgb = findViewById(R.id.tgb);

        chkJS.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(
                    CompoundButton compoundButton, boolean b)
            {
                    if(b)
                        Toast.makeText(MainActivity.this,
"Java Script checkbox selected", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(MainActivity.this,
"Java Script cjeckbox de-selected", Toast.LENGTH_SHORT).show();
            }
        });


        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String selection = "";

                if(chkJava.isChecked())
                    selection = selection + " Java ";
                if(chkCpp.isChecked())
                    selection = selection + " C++ ";
                if(chkJS.isChecked())
                    selection = selection + " JavaScript ";
                if(chkC.isChecked())
                    selection = selection + " C ";

                Toast.makeText(MainActivity.this,
"Selected languages are : "+selection,
                        Toast.LENGTH_LONG).show();

                Log.v("LANGUAGES",
                "Selected languages are : "+selection);
            }
        });

        tgb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ToggleButton t = (ToggleButton)view;
                String str = t.getText().toString();

                if(str.equals("SWITCHED ON"))
                    Toast.makeText(MainActivity.this,
"LIGHTS ON", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this,
"LIGHTS OFF", Toast.LENGTH_SHORT).show();
            }
        });
    }
}



