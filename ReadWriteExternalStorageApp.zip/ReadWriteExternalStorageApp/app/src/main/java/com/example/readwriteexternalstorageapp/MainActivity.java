package com.example.readwriteexternalstorageapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.PermissionChecker;

import android.Manifest;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    EditText edtRead , edtWrite;
    Button btnRead , btnWrite;
    File mydir , f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtRead = findViewById(R.id.edtRead);
        edtWrite =findViewById(R.id.edtWrite);
        btnRead = findViewById(R.id.btnRead);
        btnWrite = findViewById(R.id.btnWrite);

        if(ActivityCompat.checkSelfPermission(
MainActivity.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
        != PermissionChecker.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this,
new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    123);
        }

        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //mydir = getExternalFilesDir("APPFILES");

                mydir = Environment.
getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);

                Toast.makeText(MainActivity.this,
""+mydir.getPath(), Toast.LENGTH_SHORT).show();
                try {

                    f = new File(mydir,"data.txt");

                    FileOutputStream fout =
                            new FileOutputStream(f);

                    String str = edtWrite.getText().toString();

                    byte[] arr = str.getBytes();

                    fout.write(arr);

                    fout.close();

                    Toast.makeText(MainActivity.this,
"Data saved to file", Toast.LENGTH_SHORT).show();
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {

                    FileInputStream fin =
                            new FileInputStream(f);
                    String str = "";
                    int x = 0;

                    while((x = fin.read()) != -1)
                    {
                        str = str + (char)x;
                    }

                    edtRead.setText(str);
                    edtRead.setEnabled(false);
                    fin.close();
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
@NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode == 123 && grantResults[0] !=
        PermissionChecker.PERMISSION_GRANTED)
            Toast.makeText(this,
"App won't work until permission is granted",
                    Toast.LENGTH_SHORT).show();
    }
}
