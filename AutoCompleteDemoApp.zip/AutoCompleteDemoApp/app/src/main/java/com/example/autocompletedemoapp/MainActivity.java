package com.example.autocompletedemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView actv;
    MultiAutoCompleteTextView mactv;
    ArrayAdapter<String> adapter;
    List<String> lst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        actv = findViewById(R.id.actv);
        mactv = findViewById(R.id.mactv);

        lst = new ArrayList<>();
        lst.add("Madhya Pradesh");
        lst.add("Maharahstra");
        lst.add("Kerala");
        lst.add("Uttarakhand");
        lst.add("Himachal Pradesh");
        lst.add("Karnataka");
        lst.add("Odisha");

        adapter = new ArrayAdapter<>(MainActivity.this,
        android.R.layout.simple_list_item_1,lst);

        actv.setAdapter(adapter);
        mactv.setAdapter(adapter);

        actv.setThreshold(3);

        mactv.setThreshold(2);
        mactv.setTokenizer(
                new MultiAutoCompleteTextView.CommaTokenizer());
    }
}






