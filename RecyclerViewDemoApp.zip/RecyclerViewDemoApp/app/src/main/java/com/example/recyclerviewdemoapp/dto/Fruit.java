package com.example.recyclerviewdemoapp.dto;

public class Fruit {

    private String fruitname;
    private int frutimage;

    public Fruit(String fruitname, int frutimage) {
        this.fruitname = fruitname;
        this.frutimage = frutimage;
    }

    public Fruit() {
    }

    public String getFruitname() {
        return fruitname;
    }

    public void setFruitname(String fruitname) {
        this.fruitname = fruitname;
    }

    public int getFrutimage() {
        return frutimage;
    }

    public void setFrutimage(int frutimage) {
        this.frutimage = frutimage;
    }
}
