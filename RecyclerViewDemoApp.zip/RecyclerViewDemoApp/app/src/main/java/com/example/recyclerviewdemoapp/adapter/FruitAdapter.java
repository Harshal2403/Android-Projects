package com.example.recyclerviewdemoapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.recyclerviewdemoapp.R;
import com.example.recyclerviewdemoapp.dto.Fruit;
import com.example.recyclerviewdemoapp.viewholder.FruitHolder;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FruitAdapter extends RecyclerView.Adapter<FruitHolder>
{
    private Context context;
    private List<Fruit> lst;

    public FruitAdapter(Context context, List<Fruit> lst) {
        this.context = context;
        this.lst = lst;
    }

    @NonNull
    @Override
    public FruitHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View v = inflater.inflate(R.layout.fruitcard,parent,
                false);
        FruitHolder fh = new FruitHolder(v);
        return fh;
    }

    @Override
    public void onBindViewHolder(
            @NonNull FruitHolder holder, int position) {

        Fruit f = lst.get(position);
        holder.imgFruit.setImageResource(f.getFrutimage());
        holder.txtFruit.setText(f.getFruitname());

        holder.txtFruit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView tv = (TextView)view;
                Toast.makeText(context,
"You clicked "+tv.getText().toString(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {

        return lst.size();
    }
}
