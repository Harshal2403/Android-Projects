package com.example.recyclerviewdemoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.recyclerviewdemoapp.adapter.FruitAdapter;
import com.example.recyclerviewdemoapp.dto.Fruit;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView rcvFruits;
    FruitAdapter adapter;
    List<Fruit> fruitlist;
    RecyclerView.LayoutManager mgr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        rcvFruits = findViewById(R.id.rcvFruits);

        fruitlist = new ArrayList<>();

        Fruit f1 = new Fruit("Apple",
                R.drawable.apple);
        Fruit f2 = new Fruit("Berry",
                R.drawable.berry);
        Fruit f3 = new Fruit("Custard Apple",
                R.drawable.custapple);
        Fruit f4 = new Fruit("Durian",
                R.drawable.durian);
        Fruit f5 = new Fruit("Eggfruit",
                R.drawable.eggfruit);
        Fruit f6 = new Fruit("Fig",
                R.drawable.fig);
        Fruit f7 = new Fruit("Lemon",
                R.drawable.lemon);

        fruitlist.add(f1);fruitlist.add(f2);
        fruitlist.add(f3);fruitlist.add(f4);
        fruitlist.add(f5);fruitlist.add(f6);
        fruitlist.add(f7);

        adapter = new FruitAdapter(MainActivity.this,
                fruitlist);

        rcvFruits.setAdapter(adapter);

        mgr = new LinearLayoutManager(MainActivity.this,
                RecyclerView.VERTICAL,false);

//        mgr = new GridLayoutManager(MainActivity.this,
//                2,
//                RecyclerView.HORIZONTAL,false);

        rcvFruits.setLayoutManager(mgr);
    }
}





