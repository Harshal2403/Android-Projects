package com.example.recyclerviewdemoapp.viewholder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.recyclerviewdemoapp.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FruitHolder extends RecyclerView.ViewHolder
{
    public ImageView imgFruit;
    public TextView txtFruit;

    public FruitHolder(@NonNull View itemView)
    {
        super(itemView);
        imgFruit = itemView.findViewById(R.id.imgFruit);
        txtFruit = itemView.findViewById(R.id.txtFruit);
    }
}




