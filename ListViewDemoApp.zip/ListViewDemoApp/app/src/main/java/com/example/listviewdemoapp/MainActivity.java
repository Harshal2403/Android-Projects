package com.example.listviewdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView lstStates;
    ArrayAdapter<String> adapter;
    List<String> lst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lstStates = findViewById(R.id.lstStates);

        lst = new ArrayList<>();
        lst.add("Madhya Pradesh");
        lst.add("Maharashtra");
        lst.add("Kerala");
        lst.add("Himachal Pradesh");
        lst.add("Uttarakhand");
        lst.add("Karnataka");
        lst.add("Assam");
        lst.add("Andaman & Nicobar");
        lst.add("pondicherry");
        lst.add("Punjab");
        lst.add("Rajasthan");
        lst.add("Odisha");

        adapter = new ArrayAdapter<>(MainActivity.this,
android.R.layout.simple_list_item_1,lst);

        lstStates.setAdapter(adapter);

        lstStates.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView,
                                    View view, int i, long l) {

                //String item = lst.get(i);

                TextView tv = (TextView) view;
                String item = tv.getText().toString();

                Toast.makeText(MainActivity.this,
"You selected "+item, Toast.LENGTH_SHORT).show();
            }
        });
    }
}





