package com.example.radiodemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnOK , btnClear;
    EditText edtFnum , edtSnum;
    RadioGroup rgp;
    String choice = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOK = findViewById(R.id.btnOK);
        btnClear = findViewById(R.id.btnClear);
        edtSnum = findViewById(R.id.edtSnum);
        edtFnum = findViewById(R.id.edtFnum);
        rgp = findViewById(R.id.rgp);

        rgp.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(
                    RadioGroup radioGroup, int i)
            {
                    switch (i)
                    {
                        case R.id.radSum:
                                    choice = "ADD";
                                    break;

                        case R.id.radSubt:
                                    choice = "SUBT";
                                    break;
                    }
            }
        });


        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int x = Integer.parseInt(
                        edtFnum.getText().toString());
                int y = Integer.parseInt(
                        edtSnum.getText().toString());

                if(choice.equals("ADD"))
                    Toast.makeText(MainActivity.this,
"Sum of "+x+" and "+y+" is "+(x+y), Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this,
"Difference between "+x+" and "+y+" is "+(x-y),
                            Toast.LENGTH_SHORT).show();

            }
        });


        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                edtFnum.setText("");
                edtSnum.setText("");
            }
        });
    }
}
