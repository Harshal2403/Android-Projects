package com.example.multiactivitydemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class AnsActivity extends AppCompatActivity {

    TextView txtAns;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ans);

        txtAns = findViewById(R.id.txtAns);

        Intent in = getIntent();

        int a = in.getIntExtra("FNUM",0);
        int b = in.getIntExtra("SNUM",0);

        txtAns.setText("Sum of "+a+" and "+b+" is "+(a+b));
    }
}



