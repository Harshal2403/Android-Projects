package com.example.customlistviewdemoapp.dto;

public class Fruit {

    private String fruitname;
    private int fruitimage;

    public Fruit(String fruitname, int fruitimage) {
        this.fruitname = fruitname;
        this.fruitimage = fruitimage;
    }

    public Fruit() {
    }

    public String getFruitname() {
        return fruitname;
    }

    public void setFruitname(String fruitname) {
        this.fruitname = fruitname;
    }

    public int getFruitimage() {
        return fruitimage;
    }

    public void setFruitimage(int fruitimage) {
        this.fruitimage = fruitimage;
    }
}
