package com.example.customlistviewdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.customlistviewdemoapp.adapter.FruitAdapter;
import com.example.customlistviewdemoapp.dto.Fruit;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView lstFruits;
    List<Fruit> fruitlist;
    FruitAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lstFruits = findViewById(R.id.lstFruits);

        fruitlist = new ArrayList<>();

        Fruit f1 = new Fruit("Apple",
                R.drawable.apple);
        Fruit f2 = new Fruit("Berry",
                R.drawable.berry);
        Fruit f3 = new Fruit("Custard Apple",
                R.drawable.custapple);
        Fruit f4 = new Fruit("Durian",
                R.drawable.durian);
        Fruit f5 = new Fruit("Eggfruit",
                R.drawable.eggfruit);
        Fruit f6 = new Fruit("Fig",
                R.drawable.fig);
        Fruit f7 = new Fruit("Lemon",
                R.drawable.lemon);

        fruitlist.add(f1);fruitlist.add(f2);
        fruitlist.add(f3);fruitlist.add(f4);
        fruitlist.add(f5);fruitlist.add(f6);
        fruitlist.add(f7);

        adapter = new FruitAdapter(
                MainActivity.this,fruitlist);

        lstFruits.setAdapter(adapter);
    }
}




