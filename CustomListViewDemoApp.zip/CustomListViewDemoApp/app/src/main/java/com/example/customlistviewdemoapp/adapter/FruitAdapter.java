package com.example.customlistviewdemoapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.customlistviewdemoapp.R;
import com.example.customlistviewdemoapp.dto.Fruit;

import java.util.List;

public class FruitAdapter extends BaseAdapter
{
    private Context context;
    private List<Fruit> fruitlist;

    public FruitAdapter(Context context, List<Fruit> fruitlist) {
        this.context = context;
        this.fruitlist = fruitlist;
    }

    @Override
    public int getCount() {
        return fruitlist.size();
    }

    @Override
    public Object getItem(int i) {
        return fruitlist.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup)
    {
        LayoutInflater inflater = LayoutInflater.from(context);

        Toast.makeText(context,
"index is : "+i, Toast.LENGTH_SHORT).show();

        View v = inflater.inflate(R.layout.customfruit,
                viewGroup,false);

        ImageView iv = v.findViewById(R.id.imgFruit);
        TextView tv = v.findViewById(R.id.txtFruit);

        Fruit fr = fruitlist.get(i);

        iv.setImageResource(fr.getFruitimage());
        tv.setText(fr.getFruitname());

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                TextView txt = (TextView)view;
                Toast.makeText(context,
"You clicked "+txt.getText().toString(),
                        Toast.LENGTH_SHORT).show();
            }
        });

        return v;
    }
}







